"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
try {
    child_process_1.exec('cp package.json www/package.json && cp Procfile www/Profile && mkdir www/tmp/ && cd www && zip -r Archive.zip . && cd ..', (error, stdout, stderr) => {
        console.log(error, stderr, stdout);
    });
}
catch (error) {
}
//# sourceMappingURL=build.js.map